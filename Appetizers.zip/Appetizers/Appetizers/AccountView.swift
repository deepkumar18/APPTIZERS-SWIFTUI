//
//  AccountView.swift
//  Appetizers
//
//  Created by Deep kumar  on 28/09/23.
//

import SwiftUI

struct AccountView: View {
    var body: some View {
        NavigationView{
            Text("Account")
                .navigationTitle("  Account")
        }
    }
}

struct AccountView_Previews: PreviewProvider {
    static var previews: some View {
        AccountView()
    }
}
