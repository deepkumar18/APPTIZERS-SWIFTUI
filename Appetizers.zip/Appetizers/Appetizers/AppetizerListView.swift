//
//  AppetizerListView.swift
//  Appetizers
//
//  Created by Deep kumar  on 28/09/23.
//

import SwiftUI

struct AppetizerListView: View {
    
    @StateObject var viewModel  = AppetizerListViewModel()
    
    var body: some View {
        NavigationView{
            List(viewModel.appetizers) { appetizer in
                AppeetizerListCell(appetizer: appetizer)
            }
            .navigationTitle("APPETIZERS")
        }
        .onAppear {
            viewModel.getAppetizers()
        }
    }
    
}
    
 

struct AppetizerListView_Previews: PreviewProvider {
    static var previews: some View {
        AppetizerListView()
    }
}
