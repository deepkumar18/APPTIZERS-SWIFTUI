//
//  OrderView.swift
//  Appetizers
//
//  Created by Deep kumar  on 28/09/23.
//

import SwiftUI

struct OrderView: View {
    var body: some View {
        NavigationView{
            Text("Orders")
                .navigationTitle("  Orders")
        }
    }
}

struct OrderView_Previews: PreviewProvider {
    static var previews: some View {
        OrderView()
    }
}
