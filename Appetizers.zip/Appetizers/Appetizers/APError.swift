//
//  APError.swift
//  Appetizers
//
//  Created by Deep kumar  on 03/10/23.
//

import Foundation


enum APError: Error {
    case invalidURL
    case invalidResponse
    case invalidData
    case unableToComplete
}
