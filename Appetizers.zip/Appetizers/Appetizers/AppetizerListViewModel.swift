//
//  AppetizerListViewModel.swift
//  Appetizers
//
//  Created by Deep kumar  on 03/10/23.
//

import Foundation


import SwiftUI

final class AppetizerListViewModel: ObservableObject {
    
    @Published var appetizers: [Appetizer] = []
    
    
    func getAppetizers() {
        NetworkManager.shared.getAppetizers { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let apptizers):
                    self.appetizers  = apptizers
                case .failure(let error):
                    print(error.localizedDescription)
                }
            }
        }
    }
}
