//
//  AppetizersApp.swift
//  Appetizers
//
//  Created by Deep kumar  on 28/09/23.
//

import SwiftUI

@main
struct AppetizersApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            AppetizerTabView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
