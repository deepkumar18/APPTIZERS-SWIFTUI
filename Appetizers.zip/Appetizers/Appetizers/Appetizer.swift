//
//  Appetizer.swift
//  Appetizers
//
//  Created by Deep kumar  on 28/09/23.
//

import Foundation


struct Appetizer: Decodable, Identifiable {
    let id: Int
    let description: String
    let name: String
    let price: Double
    let imageURL: String
    let calories: Int
    let protein: Int
    let carbs: Int
}



struct AppetizerResponse: Decodable {
    let request: [Appetizer]
}


struct MockData {
    
    static let sampleApptizer = Appetizer(id: 00001,
                                          description: "This is the desciprtion for my appetizer.",
                                          name: "Test Appetizer",
                                          price: 9.99,
                                          imageURL: "",
                                          calories: 99,
                                          protein: 99,
                                          carbs: 99)
  
    
  static let appetizers = [sampleApptizer,sampleApptizer,sampleApptizer,sampleApptizer]
}
